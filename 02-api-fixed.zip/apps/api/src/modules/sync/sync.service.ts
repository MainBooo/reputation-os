import { ForbiddenException, Injectable, NotFoundException, Inject } from '@nestjs/common'
import { Queue } from 'bullmq'
import { PrismaService } from '../../common/prisma/prisma.service'
import { QUEUES } from '../../common/queues/queue.names'
import { JOBS } from '../../common/queues/job.names'

@Injectable()
export class SyncService {
  constructor(
    private readonly prisma: PrismaService,
    @Inject(`QUEUE_${QUEUES.SOURCE_DISCOVERY}`) private readonly sourceDiscoveryQueue: Queue,
    @Inject(`QUEUE_${QUEUES.MENTIONS_SYNC}`) private readonly mentionsQueue: Queue,
    @Inject(`QUEUE_${QUEUES.RECONCILE}`) private readonly reconcileQueue: Queue
  ) {}

  private async assertCompanyAccess(userId: string, companyId: string) {
    const company = await this.prisma.company.findUnique({ where: { id: companyId }, select: { workspaceId: true } })
    if (!company) throw new NotFoundException('Company not found')
    const member = await this.prisma.workspaceMember.findFirst({ where: { userId, workspaceId: company.workspaceId } })
    if (!member) throw new ForbiddenException('No access to company')
  }

  private async enqueueAndLog(params: {
    companyId?: string
    queue: Queue
    queueName: string
    jobName: string
    payload: Record<string, unknown>
    triggeredById?: string
  }) {
    const job = await params.queue.add(params.jobName, params.payload)
    return this.prisma.jobLog.create({
      data: {
        companyId: params.companyId,
        triggeredById: params.triggeredById,
        queueName: params.queueName,
        jobName: params.jobName,
        jobStatus: 'PENDING',
        result: { jobId: job.id, enqueued: true }
      }
    })
  }

  async discoverSources(userId: string, companyId: string) {
    await this.assertCompanyAccess(userId, companyId)
    return this.enqueueAndLog({
      companyId,
      queue: this.sourceDiscoveryQueue,
      queueName: QUEUES.SOURCE_DISCOVERY,
      jobName: JOBS.SOURCE_DISCOVERY,
      payload: { companyId },
      triggeredById: userId
    })
  }

  async startSync(userId: string, companyId: string) {
    await this.assertCompanyAccess(userId, companyId)
    return this.enqueueAndLog({
      companyId,
      queue: this.mentionsQueue,
      queueName: QUEUES.MENTIONS_SYNC,
      jobName: JOBS.MENTIONS_SYNC,
      payload: { companyId },
      triggeredById: userId
    })
  }

  async tick() {
    const companies = await this.prisma.company.findMany({ select: { id: true } })
    const results = []
    for (const company of companies) {
      results.push(await this.enqueueAndLog({
        companyId: company.id,
        queue: this.mentionsQueue,
        queueName: QUEUES.MENTIONS_SYNC,
        jobName: JOBS.MENTIONS_SYNC,
        payload: { companyId: company.id, triggeredBy: 'internal.tick' }
      }))
    }
    return { enqueued: results.length, jobs: results }
  }

  async reconcile() {
    const companies = await this.prisma.company.findMany({ select: { id: true } })
    const results = []
    for (const company of companies) {
      results.push(await this.enqueueAndLog({
        companyId: company.id,
        queue: this.reconcileQueue,
        queueName: QUEUES.RECONCILE,
        jobName: JOBS.RECONCILE,
        payload: { companyId: company.id, triggeredBy: 'internal.reconcile' }
      }))
    }
    return { enqueued: results.length, jobs: results }
  }
}
