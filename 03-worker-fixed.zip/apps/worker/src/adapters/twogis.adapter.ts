import { SourceAdapter } from './source-adapter.interface'
import { MockAdapter } from './mock.adapter'

export class TwoGisAdapter implements SourceAdapter {
  private readonly mock = new MockAdapter()

  async discoverTargets(input: any) {
    return this.mock.discoverTargets(input)
  }

  async fetchMentions(target: any) {
    return this.mock.fetchMentions(target)
  }

  async fetchRatingSnapshot(target: any) {
    return this.mock.fetchRatingSnapshot(target)
  }
}
