import { normalizeText } from '../common/utils/normalize.util'

export class VkAdapter {
  async searchPostsByQuery(query: string, _window?: { from?: Date; to?: Date }, _cursor?: string | null) {
    return [
      {
        ownerId: '-12345',
        postId: '101',
        text: `Отзывы про ${query}: отличный сервис и поддержка`,
        date: Date.now() - 1000 * 60 * 60 * 3,
        commentsCount: 2
      }
    ]
  }

  async fetchWallPostsForCommunity(community: { vkCommunityId: string; title?: string | null }, _cursor?: string | null) {
    return [
      {
        ownerId: `-${community.vkCommunityId.replace(/\D/g, '') || '777'}`,
        postId: '205',
        text: `Пост сообщества ${community.title || community.vkCommunityId} с упоминанием бренда`,
        date: Date.now() - 1000 * 60 * 60 * 2,
        commentsCount: 3
      }
    ]
  }

  async fetchCommentsForPost(ownerId: string, postId: string, _cursor?: string | null) {
    return [
      {
        commentId: '501',
        ownerId,
        postId,
        text: 'Пользовались услугами компании, все хорошо',
        date: Date.now() - 1000 * 60 * 60
      },
      {
        commentId: '502',
        ownerId,
        postId,
        text: 'Не рекомендую, задержали доставку',
        date: Date.now() - 1000 * 60 * 30
      }
    ]
  }

  normalizeVkPost(post: any) {
    return {
      externalMentionId: `vk:post:${post.ownerId}:${post.postId}`,
      content: post.text || '',
      normalizedContent: normalizeText(post.text || ''),
      publishedAt: new Date(post.date),
      commentsCount: post.commentsCount || 0,
      url: this.buildVkPostUrl(post.ownerId, post.postId)
    }
  }

  normalizeVkComment(comment: any) {
    return {
      externalMentionId: `vk:comment:${comment.ownerId}:${comment.postId}:${comment.commentId}`,
      content: comment.text || '',
      normalizedContent: normalizeText(comment.text || ''),
      publishedAt: new Date(comment.date),
      url: this.buildVkCommentUrl(comment.ownerId, comment.postId, comment.commentId)
    }
  }

  buildVkPostUrl(ownerId: string, postId: string) {
    return `https://vk.com/wall${ownerId}_${postId}`
  }

  buildVkCommentUrl(ownerId: string, postId: string, commentId: string) {
    return `https://vk.com/wall${ownerId}_${postId}?reply=${commentId}`
  }
}
