import { Inject, Injectable } from '@nestjs/common'
import { PrismaService } from '../../common/prisma/prisma.service'
import { VkAdapter } from '../../adapters/vk.adapter'
import { computeVkRelevanceScore, isVkRelevant } from '../../common/utils/relevance.util'
import { MentionService } from '../mention.service'
import { Queue } from 'bullmq'
import { QUEUES } from '../../queues/queue.names'
import { JOBS } from '../../queues/job.names'

@Injectable()
export class VkService {
  private readonly adapter = new VkAdapter()

  constructor(
    private readonly prisma: PrismaService,
    private readonly mentionService: MentionService,
    @Inject(`QUEUE_${QUEUES.VK_COMMENTS_SYNC}`) private readonly vkCommentsQueue: Queue
  ) {}

  async getCompanyContext(companyId: string) {
    const company = await this.prisma.company.findUnique({
      where: { id: companyId },
      include: { aliases: true, vkSearchProfiles: true }
    })

    if (!company) return null

    return {
      company,
      aliases: company.aliases.map((alias) => alias.normalizedValue),
      normalizedQueries: company.vkSearchProfiles.map((profile) => profile.normalizedQuery)
    }
  }

  async upsertTrackedPost(params: {
    companyId: string
    trackedCommunityId?: string | null
    post: any
  }) {
    const normalized = this.adapter.normalizeVkPost(params.post)

    return this.prisma.vkTrackedPost.upsert({
      where: { companyId_postKey: { companyId: params.companyId, postKey: `vk:${params.post.ownerId}:${params.post.postId}` } as any },
      update: {
        text: params.post.text || null,
        url: normalized.url,
        publishedAt: normalized.publishedAt,
        commentsCount: normalized.commentsCount,
        trackedCommunityId: params.trackedCommunityId || null
      },
      create: {
        companyId: params.companyId,
        trackedCommunityId: params.trackedCommunityId || null,
        ownerId: params.post.ownerId,
        postId: params.post.postId,
        postKey: `vk:${params.post.ownerId}:${params.post.postId}`,
        text: params.post.text || null,
        url: normalized.url,
        publishedAt: normalized.publishedAt,
        commentsCount: normalized.commentsCount,
        discoveryStatus: 'DISCOVERED'
      }
    })
  }

  async processRelevantPost(params: {
    companyId: string
    sourceId: string
    vkTrackedPostId: string
    post: any
  }) {
    const context = await this.getCompanyContext(params.companyId)
    if (!context) return null

    const normalized = this.adapter.normalizeVkPost(params.post)

    const score = computeVkRelevanceScore({
      text: normalized.content,
      companyName: context.company.normalizedName,
      aliases: context.aliases,
      normalizedQueries: context.normalizedQueries,
      domain: context.company.normalizedWebsite
    })

    await this.prisma.vkTrackedPost.update({
      where: { id: params.vkTrackedPostId },
      data: {
        relevanceScore: score,
        discoveryStatus: isVkRelevant(score) ? 'RELEVANT' : 'IRRELEVANT'
      }
    })

    if (!isVkRelevant(score)) return null

    await this.vkCommentsQueue.add(JOBS.VK_COMMENTS, { vkTrackedPostId: params.vkTrackedPostId })

    return this.mentionService.persistExternalMention({
      companyId: params.companyId,
      sourceId: params.sourceId,
      platform: 'VK',
      type: 'VK_POST',
      externalMentionId: normalized.externalMentionId,
      url: normalized.url,
      content: normalized.content,
      publishedAt: normalized.publishedAt,
      rawPayload: params.post,
      metadata: { relevanceScore: score },
      vkTrackedPostId: params.vkTrackedPostId
    })
  }

  async processRelevantComment(params: {
    companyId: string
    sourceId: string
    vkTrackedPostId: string
    comment: any
  }) {
    const context = await this.getCompanyContext(params.companyId)
    if (!context) return null

    const normalized = this.adapter.normalizeVkComment(params.comment)

    const score = computeVkRelevanceScore({
      text: normalized.content,
      companyName: context.company.normalizedName,
      aliases: context.aliases,
      normalizedQueries: context.normalizedQueries,
      domain: context.company.normalizedWebsite
    })

    if (!isVkRelevant(score)) return null

    return this.mentionService.persistExternalMention({
      companyId: params.companyId,
      sourceId: params.sourceId,
      platform: 'VK',
      type: 'VK_COMMENT',
      externalMentionId: normalized.externalMentionId,
      url: normalized.url,
      content: normalized.content,
      publishedAt: normalized.publishedAt,
      rawPayload: params.comment,
      metadata: { relevanceScore: score },
      vkTrackedPostId: params.vkTrackedPostId
    })
  }

  getAdapter() {
    return this.adapter
  }
}
