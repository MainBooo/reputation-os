import { Injectable } from '@nestjs/common'
import { PrismaService } from '../../common/prisma/prisma.service'
import { VkTrackedCommunityMode } from '@prisma/client'
import { VkService } from './vk.service'

@Injectable()
export class VkCommunityService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly vkService: VkService
  ) {}

  async run(companyId: string, mode: VkTrackedCommunityMode) {
    const company = await this.prisma.company.findUnique({ where: { id: companyId } })
    if (!company) return { communitiesCount: 0 }

    const source = await this.prisma.source.findFirst({
      where: { workspaceId: company.workspaceId, platform: 'VK' }
    })
    if (!source) return { communitiesCount: 0 }

    const communities = await this.prisma.vkTrackedCommunity.findMany({
      where: { companyId, mode, isActive: true }
    })

    const adapter = this.vkService.getAdapter()

    for (const community of communities) {
      const posts = await adapter.fetchWallPostsForCommunity(community)
      for (const post of posts) {
        const trackedPost = await this.vkService.upsertTrackedPost({
          companyId,
          trackedCommunityId: community.id,
          post
        })

        await this.vkService.processRelevantPost({
          companyId,
          sourceId: source.id,
          vkTrackedPostId: trackedPost.id,
          post
        })

        await this.prisma.vkTrackedCommunity.update({
          where: { id: community.id },
          data: { lastSyncedAt: new Date() }
        })
      }
    }

    return { communitiesCount: communities.length }
  }
}
