import { Injectable } from '@nestjs/common'
import { PrismaService } from '../../common/prisma/prisma.service'
import { VkService } from './vk.service'

@Injectable()
export class VkBrandSearchService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly vkService: VkService
  ) {}

  async run(companyId: string) {
    const profiles = await this.prisma.vkSearchProfile.findMany({
      where: { companyId, isActive: true, mode: 'BRAND_SEARCH' },
      orderBy: { priority: 'asc' }
    })

    const adapter = this.vkService.getAdapter()
    const company = await this.prisma.company.findUnique({ where: { id: companyId } })
    if (!company) return { profilesCount: 0 }

    const source = await this.prisma.source.findFirst({
      where: { workspaceId: company.workspaceId, platform: 'VK' }
    })
    if (!source) return { profilesCount: profiles.length }

    for (const profile of profiles) {
      const posts = await adapter.searchPostsByQuery(profile.query)
      for (const post of posts) {
        const trackedPost = await this.vkService.upsertTrackedPost({ companyId, post })
        await this.vkService.processRelevantPost({
          companyId,
          sourceId: source.id,
          vkTrackedPostId: trackedPost.id,
          post
        })
      }
    }

    return { profilesCount: profiles.length }
  }
}
