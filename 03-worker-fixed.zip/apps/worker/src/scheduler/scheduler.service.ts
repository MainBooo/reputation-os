import { Inject, Injectable, OnModuleInit } from '@nestjs/common'
import { Queue } from 'bullmq'
import { PrismaService } from '../common/prisma/prisma.service'
import { QUEUES } from '../queues/queue.names'
import { JOBS } from '../queues/job.names'

@Injectable()
export class SchedulerService implements OnModuleInit {
  constructor(
    private readonly prisma: PrismaService,
    @Inject(`QUEUE_${QUEUES.REVIEWS_SYNC}`) private readonly reviewsQueue: Queue,
    @Inject(`QUEUE_${QUEUES.RATING_REFRESH}`) private readonly ratingsQueue: Queue,
    @Inject(`QUEUE_${QUEUES.MENTIONS_SYNC}`) private readonly mentionsQueue: Queue,
    @Inject(`QUEUE_${QUEUES.RECONCILE}`) private readonly reconcileQueue: Queue,
    @Inject(`QUEUE_${QUEUES.VK_BRAND_SEARCH_DISCOVERY}`) private readonly vkBrandQueue: Queue,
    @Inject(`QUEUE_${QUEUES.VK_PRIORITY_COMMUNITIES_SYNC}`) private readonly vkCommunitiesQueue: Queue,
    @Inject(`QUEUE_${QUEUES.VK_OWNED_COMMUNITY_SYNC}`) private readonly vkOwnedQueue: Queue,
    @Inject(`QUEUE_${QUEUES.VK_RECONCILE}`) private readonly vkReconcileQueue: Queue
  ) {}

  async onModuleInit() {
    const companies = await this.prisma.company.findMany({ select: { id: true } }).catch(() => [])
    for (const company of companies) {
      await this.reviewsQueue.add(JOBS.REVIEWS_SYNC, { companyId: company.id }, { repeat: { every: 2 * 60 * 60 * 1000 } })
      await this.ratingsQueue.add(JOBS.RATING_REFRESH, { companyId: company.id }, { repeat: { every: 12 * 60 * 60 * 1000 } })
      await this.mentionsQueue.add(JOBS.MENTIONS_SYNC, { companyId: company.id }, { repeat: { every: 24 * 60 * 60 * 1000 } })
      await this.reconcileQueue.add(JOBS.RECONCILE, { companyId: company.id }, { repeat: { every: 24 * 60 * 60 * 1000 } })

      await this.vkBrandQueue.add(JOBS.VK_BRAND_SEARCH, { companyId: company.id }, { repeat: { every: 8 * 60 * 60 * 1000 } })
      await this.vkCommunitiesQueue.add(JOBS.VK_PRIORITY_COMMUNITIES, { companyId: company.id }, { repeat: { every: 5 * 60 * 60 * 1000 } })
      await this.vkOwnedQueue.add(JOBS.VK_OWNED_COMMUNITY, { companyId: company.id }, { repeat: { every: 60 * 60 * 1000 } })
      await this.vkReconcileQueue.add(JOBS.VK_RECONCILE, { companyId: company.id }, { repeat: { every: 24 * 60 * 60 * 1000 } })
    }
  }
}
