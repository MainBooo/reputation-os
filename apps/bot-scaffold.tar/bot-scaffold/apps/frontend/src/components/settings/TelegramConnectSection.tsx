'use client'

import { useState, useEffect, useCallback, useRef } from 'react'

interface TelegramStatus {
  linked: boolean
  linkedAt: string | null
}

const API_BASE = '/api/telegram'

export function TelegramConnectSection() {
  const [status, setStatus] = useState<TelegramStatus | null>(null)
  const [loading, setLoading] = useState(false)
  const [connecting, setConnecting] = useState(false)
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const fetchStatus = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE}/status`, { credentials: 'include' })
      if (res.ok) {
        const data = await res.json()
        setStatus(data)
        return data as TelegramStatus
      }
    } catch {
      // ignore
    }
    return null
  }, [])

  useEffect(() => {
    fetchStatus()
  }, [fetchStatus])

  const stopPolling = useCallback(() => {
    if (pollRef.current) {
      clearInterval(pollRef.current)
      pollRef.current = null
    }
  }, [])

  const startPolling = useCallback(() => {
    stopPolling()
    pollRef.current = setInterval(async () => {
      const data = await fetchStatus()
      if (data?.linked) {
        stopPolling()
        setConnecting(false)
      }
    }, 3000)
  }, [fetchStatus, stopPolling])

  useEffect(() => () => stopPolling(), [stopPolling])

  const handleConnect = async () => {
    setLoading(true)
    try {
      const res = await fetch(`${API_BASE}/link-token`, {
        method: 'POST',
        credentials: 'include',
      })
      if (!res.ok) throw new Error('Ошибка генерации ссылки')
      const { url } = await res.json()
      window.open(url, '_blank', 'noopener,noreferrer')
      setConnecting(true)
      startPolling()
    } catch (e) {
      alert('Не удалось создать ссылку. Попробуйте позже.')
    } finally {
      setLoading(false)
    }
  }

  const handleUnlink = async () => {
    if (!confirm('Отвязать Telegram? Вы перестанёте получать уведомления.')) return
    setLoading(true)
    try {
      await fetch(`${API_BASE}/unlink`, { method: 'DELETE', credentials: 'include' })
      setStatus({ linked: false, linkedAt: null })
    } catch {
      alert('Ошибка отвязки. Попробуйте позже.')
    } finally {
      setLoading(false)
    }
  }

  if (status === null) {
    return (
      <div className="telegram-section">
        <p className="text-muted">Загрузка...</p>
      </div>
    )
  }

  return (
    <div className="telegram-section">
      <h3 className="section-title">Telegram-уведомления</h3>

      {status.linked ? (
        <div className="telegram-linked">
          <span className="status-badge status-badge--green">✅ Подключён</span>
          {status.linkedAt && (
            <p className="text-muted text-sm">
              Привязан {new Date(status.linkedAt).toLocaleDateString('ru-RU')}
            </p>
          )}
          <button
            className="btn btn-danger btn-sm"
            onClick={handleUnlink}
            disabled={loading}
          >
            {loading ? 'Отключение...' : 'Отвязать Telegram'}
          </button>
        </div>
      ) : (
        <div className="telegram-unlinked">
          <p className="text-muted">
            Получайте мгновенные уведомления о новых отзывах прямо в Telegram.
          </p>

          {connecting ? (
            <div className="connecting-hint">
              <span className="spinner" />
              <p>
                Откройте бота в Telegram и нажмите <strong>Старт</strong>.
                <br />
                Ожидаем подтверждения...
              </p>
              <button
                className="btn btn-link btn-sm"
                onClick={() => { stopPolling(); setConnecting(false) }}
              >
                Отмена
              </button>
            </div>
          ) : (
            <button
              className="btn btn-primary"
              onClick={handleConnect}
              disabled={loading}
            >
              {loading ? 'Создаём ссылку...' : '🔗 Подключить Telegram'}
            </button>
          )}
        </div>
      )}
    </div>
  )
}
