import { Module } from '@nestjs/common'
import { TelegramController } from './telegram.controller'
import { TelegramService } from './telegram.service'

@Module({
  controllers: [TelegramController],
  providers: [TelegramService],
  exports: [TelegramService],
})
export class TelegramApiModule {}

// ⚠️ Добавить TelegramApiModule в imports[] в apps/api/src/app.module.ts
