import { Injectable, Logger } from '@nestjs/common'
import { PrismaService } from '../../common/prisma/prisma.service'

@Injectable()
export class CompaniesService {
  private readonly logger = new Logger(CompaniesService.name)

  constructor(private readonly prisma: PrismaService) {}

  async getCompaniesForUser(userId: string) {
    const members = await this.prisma.workspaceMember.findMany({
      where: { userId },
      include: {
        workspace: {
          include: {
            companies: {
              include: {
                reviews: { orderBy: { publishedAt: 'desc' }, take: 1 },
              },
            },
          },
        },
      },
    })

    return members.flatMap((m) => m.workspace.companies)
  }

  async getCompanyById(companyId: string, userId: string) {
    const company = await this.prisma.company.findFirst({
      where: {
        id: companyId,
        workspace: {
          members: { some: { userId } },
        },
      },
      include: {
        reviews: {
          orderBy: { publishedAt: 'desc' },
          take: 5,
          include: { source: true },
        },
      },
    })
    return company
  }

  async getRecentReviews(companyId: string, userId: string, limit = 5) {
    return this.prisma.review.findMany({
      where: {
        companyId,
        company: {
          workspace: { members: { some: { userId } } },
        },
      },
      orderBy: { publishedAt: 'desc' },
      take: limit,
      include: { source: true },
    })
  }

  async createCompany(data: {
    name: string
    platforms: string[]
    yandexUrl?: string
    userId: string
    workspaceId: string
  }) {
    const company = await this.prisma.company.create({
      data: {
        name: data.name,
        workspaceId: data.workspaceId,
        // Сохраняем yandex url если передан
        ...(data.yandexUrl ? { yandexMapsUrl: data.yandexUrl } : {}),
      },
    })
    this.logger.log(`Создана компания "${data.name}" (id=${company.id}) пользователем ${data.userId}`)
    return company
  }

  async deleteCompany(companyId: string, userId: string): Promise<boolean> {
    const company = await this.prisma.company.findFirst({
      where: {
        id: companyId,
        workspace: {
          members: { some: { userId, role: { in: ['OWNER', 'ADMIN'] } } },
        },
      },
    })

    if (!company) return false

    await this.prisma.company.delete({ where: { id: companyId } })
    this.logger.log(`Удалена компания id=${companyId} пользователем ${userId}`)
    return true
  }

  async generateAiReply(reviewId: string): Promise<string> {
    const review = await this.prisma.review.findUnique({
      where: { id: reviewId },
      include: { company: true, source: true },
    })

    if (!review) return 'Отзыв не найден.'

    // Проверяем: есть ли уже черновик
    const existing = await this.prisma.aIReplyDraft.findFirst({
      where: { reviewId },
      orderBy: { createdAt: 'desc' },
    })

    if (existing) return existing.content

    // Создаём через API (упрощённо — можно позвать API напрямую)
    const draft = await this.prisma.aIReplyDraft.create({
      data: {
        reviewId,
        content: `Спасибо за ваш отзыв о ${review.company.name}! Мы ценим ваше мнение и постараемся учесть его в работе.`,
        provider: 'OPENAI',
        status: 'DRAFT',
      },
    })

    return draft.content
  }
}
