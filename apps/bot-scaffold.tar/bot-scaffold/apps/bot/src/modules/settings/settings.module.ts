import { Module } from '@nestjs/common'
import { SettingsUpdate } from './settings.update'
import { SettingsService } from './settings.service'

@Module({
  providers: [SettingsUpdate, SettingsService],
  exports: [SettingsService],
})
export class SettingsModule {}
