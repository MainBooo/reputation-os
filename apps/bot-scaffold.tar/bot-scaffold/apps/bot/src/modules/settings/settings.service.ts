import { Injectable, Logger } from '@nestjs/common'
import { PrismaService } from '../../common/prisma/prisma.service'

@Injectable()
export class SettingsService {
  private readonly logger = new Logger(SettingsService.name)

  constructor(private readonly prisma: PrismaService) {}

  async getNotificationRules(userId: string, companyId?: string) {
    return this.prisma.notificationRule.findMany({
      where: {
        userId,
        channel: 'TELEGRAM',
        ...(companyId ? { companyId } : {}),
      },
    })
  }

  async toggleRule(userId: string, companyId: string, eventType: string): Promise<boolean> {
    const existing = await this.prisma.notificationRule.findFirst({
      where: { userId, companyId, eventType, channel: 'TELEGRAM' },
    })

    if (existing) {
      await this.prisma.notificationRule.delete({ where: { id: existing.id } })
      this.logger.log(`Отключено правило ${eventType} для userId=${userId}`)
      return false
    } else {
      await this.prisma.notificationRule.create({
        data: { userId, companyId, eventType, channel: 'TELEGRAM' },
      })
      this.logger.log(`Включено правило ${eventType} для userId=${userId}`)
      return true
    }
  }

  async disableAll(userId: string): Promise<void> {
    await this.prisma.notificationRule.deleteMany({
      where: { userId, channel: 'TELEGRAM' },
    })
    this.logger.log(`Все TELEGRAM-правила отключены для userId=${userId}`)
  }
}
