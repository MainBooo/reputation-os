-- AlterEnum
ALTER TYPE "NotificationChannel" ADD VALUE 'TELEGRAM';

-- AlterTable: add telegram fields to User
ALTER TABLE "User"
  ADD COLUMN "telegramChatId"   BIGINT   UNIQUE,
  ADD COLUMN "telegramLinkedAt" TIMESTAMP(3);

-- CreateTable: TelegramLinkToken
CREATE TABLE "TelegramLinkToken" (
    "id"        TEXT         NOT NULL,
    "userId"    TEXT         NOT NULL,
    "token"     TEXT         NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "TelegramLinkToken_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "TelegramLinkToken_userId_key"  ON "TelegramLinkToken"("userId");
CREATE UNIQUE INDEX "TelegramLinkToken_token_key"   ON "TelegramLinkToken"("token");

ALTER TABLE "TelegramLinkToken"
  ADD CONSTRAINT "TelegramLinkToken_userId_fkey"
  FOREIGN KEY ("userId") REFERENCES "User"("id")
  ON DELETE CASCADE ON UPDATE CASCADE;
